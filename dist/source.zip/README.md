# YummyAnime Manager

**[Подробная инструкция по работе с программой](USER_GUIDE.md)**

Windows-приложение для загрузки аниме по ссылке YummyAnime с выбором плеера,
озвучек, сезона и реально доступного качества. Поддерживает multi-audio MKV,
Plex-friendly naming и `.plexmatch`.

## Возможности

- URL YummyAnime → список плееров, озвучек и серий;
- динамическое определение реально доступных качеств;
- источники: CVH, Kodik, Aksor, Sibnet, Rutube, VK Video, Zedfilm и прямые media URL;
- Alloha через self-hosted resolver из официального YummyAnime Lampa plugin;
- HLS/DASH через FFmpeg без перекодирования;
- несколько озвучек → один MKV через MKVToolNix;
- Plex-структура `Название / Season XX / Название - SxxEyy.mkv`;
- автоматический `.plexmatch`;
- отдельный прогресс текущей серии и всей очереди;
- история десяти последних ссылок прямо в строке ввода;
- подробный журнал диагностики в настройках;
- главы в MKV из исходного видео или метки OP/ED/recap из AniSkip;
- Windows EXE с включённым Python runtime и FFmpeg.
- автоматическая проверка обновлений при запуске EXE и BAT;

## Готовая Windows-версия

Готовый файл находится в `dist/YummyAnimeManager.exe`.

Это сборка PyInstaller версии 4.4.1. Для объединения озвучек нужен MKVToolNix.
Настройки хранятся в `%USERPROFILE%\\.yummy_anime_manager` и не входят в репозиторий.

## Запуск из исходников

Требуется Python 3.11+.

```bat
install.bat
run.bat
```

Или вручную:

```bash
python -m venv .venv
.venv\\Scripts\\activate
pip install -r requirements.txt
python main.py
```

## Сборка простого PyInstaller EXE

```bat
build_exe.bat
```

Команда создаёт ту же PyInstaller-сборку исходного GUI, что находится в `dist/`.

## Alloha

Для Alloha требуется официальный self-hosted resolver:

```bat
install_alloha_resolver.bat
start_alloha_resolver.bat
```

Нужен Node.js LTS. По умолчанию приложение ожидает resolver по адресу
`http://127.0.0.1:8790`.

## Токен YummyAnime

Используется только публичный application token в заголовке `X-Application`.
Приватный токен приложение не запрашивает и не хранит.

## Главы и диагностика

При включённом параметре «Добавлять главы в MKV» приложение сохраняет главы,
которые уже есть в исходном видео. Если их нет, приложение ищет временные метки
вступления, концовки и краткого пересказа в AniSkip по MyAnimeList ID, номеру и
длительности серии. Если надёжных меток нет, главы не добавляются. Видео с
найденными главами сохраняется как MKV без перекодирования.

Подробный журнал включается в «Настройках». Файлы журнала находятся в
`%USERPROFILE%\\.yummy_anime_manager\\logs`; кнопку открытия папки можно найти там же.
Журнал ограничен по размеру, а параметры URL скрываются.

## Тесты

```bash
python -m unittest discover -s tests -v
python test_resolvers.py
python test_plexmatch.py
```

## Важное замечание

Приложение должно использоваться только для контента, который пользователь имеет
право сохранять. Оно не предназначено для обхода DRM.

## Third-party / licensing

См. [NOTICE.md](NOTICE.md). Отдельная лицензия проекта намеренно не добавлена до
проверки прав на resolver-код, основанный на поведении/референсах сторонних
проектов.
